"""
tests/test_password_generator.py

Automated unit tests for the pure password-generation logic.

Run with (from the project root):
    python -m unittest discover -s tests -v

These tests do NOT touch the GUI at all -- that's the whole point of
keeping password_generator.py free of Tkinter code. That separation is
what makes automated testing like this possible.
"""

import sys
import os
import unittest

# Allow running this test file directly (python tests/test_password_generator.py)
# by adding the project root to the import path.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from password_generator import (  # noqa: E402
    PasswordOptions,
    PasswordGeneratorError,
    generate_password,
)


def has_upper(pw: str) -> bool:
    return any(c.isupper() for c in pw)


def has_lower(pw: str) -> bool:
    return any(c.islower() for c in pw)


def has_digit(pw: str) -> bool:
    return any(c.isdigit() for c in pw)


def has_symbol(pw: str) -> bool:
    return any(not c.isalnum() for c in pw)


AMBIGUOUS = set("0Ol1I")


class TestPasswordGeneration(unittest.TestCase):

    def test_minimum_length_all_categories(self):
        options = PasswordOptions(length=8, use_upper=True, use_lower=True,
                                   use_digits=True, use_symbols=True)
        pw = generate_password(options)
        self.assertEqual(len(pw), 8)
        self.assertTrue(has_upper(pw) and has_lower(pw) and has_digit(pw) and has_symbol(pw))

    def test_maximum_length(self):
        options = PasswordOptions(length=128, use_upper=True, use_lower=True)
        pw = generate_password(options)
        self.assertEqual(len(pw), 128)

    def test_length_above_maximum_rejected(self):
        options = PasswordOptions(length=200, use_upper=True, use_lower=True)
        with self.assertRaises(PasswordGeneratorError):
            generate_password(options)

    def test_length_below_minimum_rejected(self):
        options = PasswordOptions(length=5, use_upper=True, use_lower=True)
        with self.assertRaises(PasswordGeneratorError):
            generate_password(options)

    def test_single_category_selected_rejected(self):
        options = PasswordOptions(length=10, use_upper=True)
        with self.assertRaises(PasswordGeneratorError):
            generate_password(options)

    def test_no_category_selected_rejected(self):
        options = PasswordOptions(length=10)
        with self.assertRaises(PasswordGeneratorError):
            generate_password(options)

    def test_two_categories_present_and_only_those(self):
        options = PasswordOptions(length=12, use_digits=True, use_symbols=True)
        pw = generate_password(options)
        self.assertTrue(has_digit(pw) and has_symbol(pw))
        self.assertFalse(has_upper(pw) or has_lower(pw))

    def test_ambiguous_characters_excluded(self):
        options = PasswordOptions(length=20, use_upper=True, use_lower=True,
                                   use_digits=True, use_symbols=True,
                                   exclude_ambiguous=True)
        for _ in range(100):
            pw = generate_password(options)
            self.assertFalse(set(pw) & AMBIGUOUS, f"Ambiguous character leaked in: {pw}")

    def test_category_guarantee_statistical(self):
        # Run many times to build confidence the guarantee never fails
        # by chance (it shouldn't fail at all, since it's guaranteed by
        # construction rather than by probability).
        options = PasswordOptions(length=12, use_upper=True, use_symbols=True)
        for _ in range(300):
            pw = generate_password(options)
            self.assertTrue(has_upper(pw) and has_symbol(pw))

    def test_length_equals_selected_category_count(self):
        # Real-world minimum (8) already exceeds max categories (4),
        # so this exercises the boundary where length == categories
        # would matter if the minimum length were ever lowered.
        options = PasswordOptions(length=8, use_upper=True, use_lower=True,
                                   use_digits=True, use_symbols=True)
        pw = generate_password(options)
        self.assertEqual(len(pw), 8)
        self.assertTrue(has_upper(pw) and has_lower(pw) and has_digit(pw) and has_symbol(pw))


if __name__ == "__main__":
    unittest.main()
