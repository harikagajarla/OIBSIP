"""
tests/test_strength_checker.py

Automated unit tests for the password-strength estimator.

Run with (from the project root):
    python -m unittest discover -s tests -v
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from strength_checker import calculate_strength  # noqa: E402


class TestStrengthChecker(unittest.TestCase):

    def test_empty_password_is_weak(self):
        self.assertEqual(calculate_strength(""), "Weak")

    def test_short_single_category_is_weak(self):
        self.assertEqual(calculate_strength("ab"), "Weak")

    def test_long_single_category_is_weak(self):
        # Long but only one character category present -- still weak
        # under this transparent, category-diversity-aware scoring.
        self.assertEqual(calculate_strength("abcdefgh"), "Weak")

    def test_medium_example(self):
        self.assertEqual(calculate_strength("Password1"), "Medium")

    def test_strong_example(self):
        self.assertEqual(calculate_strength("Ab3!kQ9z@Lm2"), "Strong")


if __name__ == "__main__":
    unittest.main()
